# clgpypackage
  Clgpy is a fundamental package that can be used by a person who is new to programming in python.
  It is mainly useful for college students.

  Clgpy constitutes of following functions:

  isPrime(number)  
  PrimeBtwInterval(lower, upper)  
  isPalindrome(num)  
  isArmstrong(num)  
  halfPyramidpattern(n)  
  leftHalfPyramidpattern(rows)  
  downwardHalfPyramidpattern(rows)  
  equilateralTrianglepattern(size)  
  rightStartTrianglepattern(rows)  
  downEquilateralTrianglepattern(rows)  
  filledDiamondpattern(rows)  
  menPantShapedpattern(rows)   
  Flagpattern(row)  
  PascalTrianglepattern(row)  
  ChristmasTreepattern(row)  
  Starpattern(n)  
  factorial(n)   
  interest(p,t,r) #principle, time period, rate  
  progression(a,d,n) #start, difference/rate, no of terms  
  matSummary(m1) # Pass matrix as numpy array  
  matsumprod(m1,m2) # Pass matrix as numpy array  
